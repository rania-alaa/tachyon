var arch=document.getElementsByTagName("a");
function f1()
{

console.log(arch);

location.href="/Books/Book_page.html";

}
