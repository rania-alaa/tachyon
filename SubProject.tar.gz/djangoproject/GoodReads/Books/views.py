from django.http import HttpResponse
from django.shortcuts import render
from Books.models import books

def index(request):
	data=books.objects.all().filter()	
	
	return render(request,'Books/AllBooks.html',{'books':data})
def book_page(request,book_id):
	
	data=books.objects.get(id=book_id)
	html=''
	html+='<head> <link rel="stylesheet" type="text/css" href='+str('/static/Bookcss/Droplist.css') + '/></head>'
	html+='<h1>Title:'+ str(data.name) +'</h1>'
	html+='<img src='+ str('/static/cover.jpg' )+ '></img>' 
	html+='<h1>Summary:'+str(data.summary)+'</h1>'
	html+='<div class="Author"><h1>Author</h1></div><divclass="dropdown"><button onclick="DropdownClick()" class="dropbtn">Want to Read</button><div id="DropDownContent"><a href="#">Read</a><a href="#">Currently Read</a><a href="#">Want to Read</a></div></div>'
	html+='<script src='+str( '/static/Booksjs/Droplist.js') +'></script>'
	return HttpResponse(html)


