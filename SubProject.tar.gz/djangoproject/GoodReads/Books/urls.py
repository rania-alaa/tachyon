from django.conf.urls import include, url
from django.urls import path
from Books import views
app_name='Books'
urlpatterns = [
   
    url(r'^$', views.index, name='index'),
	url(r'^(?P<book_id>[0-9]+)/$',views.book_page,name='book_page'),
]
